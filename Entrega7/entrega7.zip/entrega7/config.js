module.exports = {
    /* Configuración de los datos de acceso a la BD */
    mysqlConfig: {
        database: "entregable6",
        host: "localhost",
        user: "root",
        password: ""
    },
    
    /* Puerto de escucha */
    port: 3000
};

